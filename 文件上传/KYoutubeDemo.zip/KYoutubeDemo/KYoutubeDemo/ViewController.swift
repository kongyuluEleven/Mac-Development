//
//  ViewController.swift
//  KYoutubeDemo
//
//  Created by kongyulu on 2020/10/12.
//  Copyright © 2020 wondershare. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

