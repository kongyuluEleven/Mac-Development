//
//  MTFilterGroup.swift
//  MetalFilters
//
//  Created by xushuifeng on 2018/6/17.
//  Copyright © 2018 shuifeng.me. All rights reserved.
//

import Foundation

class MTFilterGroup {
    
    private var filters: [MTFilter] = []
    
    func add(filter: MTFilter) {
        
    }
    
}
