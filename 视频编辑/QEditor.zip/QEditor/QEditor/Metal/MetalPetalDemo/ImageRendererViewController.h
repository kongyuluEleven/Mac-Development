//
//  ViewController.h
//  MetalPetalDemo
//
//  Created by YuAo on 25/06/2017.
//  Copyright © 2017 MetalPetal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageRendererViewController : UIViewController

@end

