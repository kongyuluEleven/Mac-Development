//
//  BlendModeViewController.h
//  MetalPetalDemo
//
//  Created by 杨乃川 on 2018/9/19.
//  Copyright © 2018年 MetalPetal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BlendModeViewController : UIViewController

@end
