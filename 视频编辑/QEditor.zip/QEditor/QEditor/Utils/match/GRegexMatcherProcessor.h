//
//  GRegexMatcherProcessor.h
//  GMatchingKit
//
//  Created by GIKI on 2018/4/18.
//  Copyright © 2018年 GIKI. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IMatcherProcessor.h"
#import "IMatcherObject.h"
@interface GRegexMatcherProcessor : NSObject<IMatcherProcessor>

@end
