//
//  NavigationBar.swift
//  QEditor
//
//  Created by Q YiZhong on 2019/10/6.
//  Copyright © 2019 YiZhong Qi. All rights reserved.
//

import UIKit

class NavigationBar: UINavigationBar {
    
    

}
